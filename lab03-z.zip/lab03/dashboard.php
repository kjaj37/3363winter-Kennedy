<?php
require_once "auth.php";
require_login();

$username = $_SESSION["username"] ?? "User";
$login_time = $_SESSION["login_time"] ?? "Unknown";
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Lab 03 - Dashboard</title>
    <link rel="stylesheet" href="styles.css">
</head>
<body>
    <div class="container">
        <h1>Protected Page</h1>
        
        <div class="alert alert-success">
            You are logged in.
        </div>

        <div class="card">
            <p>Welcome, <strong><?=  htmlspecialchars(string: $username) ?></strong>.</p>
            <p>Login time: <strong><?=  htmlspecialchars(string: $login_time) ?></strong></p>

            <p class="small">
                This page is protected using PHP sessions. If you are not logged in, you are redirected to the login page.
            </p>
            <p><a href="logout.php">Log out</a></p>
        </div>
    </div>
</body>
</html>