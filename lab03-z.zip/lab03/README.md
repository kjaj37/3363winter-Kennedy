Lab 03 - PHP Forms + Validation
A website that allows you to log in with the correct credentials and informs you of what time you logged in. It will also tell you what you got wrong if your login failed.

Features:
validation
sessions
protected page
logout
login time

Instructions:
Open XAMPP Control Panel and start Apache
Folder path - C:\xampp\htdocs\3363winter\lab03\

How to test:
http://localhost/3363winter/lab03/ - redirects to login.php
Submit empty login form - Shows required fielderrors
Wrong credentials - Shows invalid login message
Correct credentials - Redirects to dashboard and shows “Welcome, student.”
Click log out - Returns to login and session is ended

Demo Credentials:
student / Lab03!

Reflection: I learned how to create a secure website with login credentials that will redirect you back to the login screen if you attempt you go to a page by using the link directly. I also learned how to create a button that logs you out and clears your login information to maintain security.