<?php
// auth.php
// Centralized session start + helper functions
session_start();
date_default_timezone_set(timezoneId: 'America/Halifax');

if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

function require_login(): void {
    if  (empty($_SESSION['logged_in'])) {
        header(header: "Location: login.php");
        exit;
    }
}