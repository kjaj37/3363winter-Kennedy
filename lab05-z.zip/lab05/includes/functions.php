<?php
function e(string $value): string {
return htmlspecialchars($value, ENT_QUOTES, "UTF-8");
}
function get_int_or_null($value): ?int {
if (!isset($value)) return null;
if (!is_numeric($value)) return null;
$int = (int)$value;
return ($int > 0) ? $int : null;
}
function redirect(string $path): void {
header("Location: {$path}");
exit;
}
function is_valid_email(string $email): bool {
return (bool) filter_var($email, FILTER_VALIDATE_EMAIL);
}
/*
Optional: Basic message banner
*/
function flash_message(): string {
$msg = $_GET["msg"] ?? "";
$map = [
"created" => "Student created successfully.",
"updated" => "Student updated successfully.",
"deleted" => "Student deleted successfully.",
"error" => "Something went wrong. Please try again."
];
return $map[$msg] ?? "";
}