<?php
require_once __DIR__ . "/../config/db.php";
require_once __DIR__ . "/../includes/functions.php";
$flash = flash_message();
// Optional search (bonus)
$q = trim($_GET["q"] ?? "");
$search = ($q !== "");
if ($search) {
$sql = "SELECT student_id, full_name, email, program, created_at
FROM students
WHERE full_name LIKE :q1 OR program LIKE :q2
ORDER BY created_at DESC";
$stmt = $pdo->prepare($sql);
$like = "%{$q}%";
$stmt->execute([
":q1" => $like,
":q2" => $like
]);
} else {
$sql = "SELECT student_id, full_name, email, program, created_at
FROM students
ORDER BY created_at DESC";
$stmt = $pdo->query($sql);
}
$students = $stmt->fetchAll();
?>
<?php require_once __DIR__ . "/../includes/header.php"; ?>
<div class="topbar">
<div>
<a class="btn" href="create.php">+ Add Student</a>
</div>
<form class="search" method="get" action="index.php">
<input type="text" name="q" placeholder="Search name or program..." value="<?= e($q) ?>" />
<button class="btn" type="submit">Search</button>
<?php if ($search): ?>
<a class="btn" href="index.php">Clear</a>
<?php endif; ?>
</form>
</div>
<?php if ($flash): ?>
<div class="msg"><?= e($flash) ?></div>
<?php endif; ?>
<table>
<thead>
<tr>
<th>ID</th>
<th>Full Name</th>
<th>Email</th>
<th>Program</th>
<th>Created</th>
<th>Actions</th>
</tr>
</thead>
<tbody>
<?php if (!$students): ?>
<tr><td colspan="6">No students found.</td></tr>
<?php else: ?>
<?php foreach ($students as $s): ?>
<tr>
<td><?= (int)$s["student_id"] ?></td>
<td><?= e($s["full_name"]) ?></td>
<td><?= e($s["email"]) ?></td>
<td><?= e($s["program"]) ?></td>
<td><?= e($s["created_at"]) ?></td>
<td>
<a class="btn" href="edit.php?id=<?= (int)$s["student_id"] ?>">Edit</a>
<a class="btn danger" href="delete.php?id=<?= (int)$s["student_id"] ?>">Delete</a>
</td>
</tr>
<?php endforeach; ?>
<?php endif; ?>
</tbody>
</table>
<?php require_once __DIR__ . "/../includes/footer.php"; ?>