## Database
Database name:
Table 1 (parent):
Table 2 (child):
Primary key (Table 1):
Foreign key (Table 2):
## Data
Rows in Table 1:
Rows in Table 2:
## JOIN query I ran
```sql
-- paste your JOIN query here