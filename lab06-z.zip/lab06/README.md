# Lab 06 — PHP Web Security & Sessions (Secure Notes)
**Student Name:** Kennedy John
**Date:** 26/02/10
## 1) What I built (1–2 sentences)
A website with secure logins and the ability to grant admin privilages that automatically creates new user profiles with registration. 
## 2) How to run my lab
**Database name:** `lab06_kennedy'
**Start page URL:**
Steps:
1. Start XAMPP (Apache + MySQL)
2. Open phpMyAdmin and create my database
3. Run the Lab06 SQL to create tables: `users`, `notes`
4. Update `app/db.php` with my DB name
5. Open the start page URL above
## 3) Security features checklist:
Only admins can access certain areas
Login requires a specific password and will not work otherwise
Redirected if not logged in
Cannot run code through the notes
## 4) Test Results (PASS/FAIL)
- Register works: Pass
- Login works (correct password): Pass
- Login fails (wrong password): Pass
- Dashboard redirects when logged out: Pass
- Create note works: Pass
- XSS test does NOT run (`<script>alert('xss')</script>`): Pass
- Admin page (user gets 403): Pass
- Admin page (admin can view): Pass
- Session timeout works: Pass
## 5) Reflection: what I have learned from Lab 06 (3-5 sentences)
I learned how to create a secure website. I also learned how to grant admin privilages to certain user. I also learned how to make a user timeout if they have been logged in too long.